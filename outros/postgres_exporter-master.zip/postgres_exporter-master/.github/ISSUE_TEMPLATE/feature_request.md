---
name: Feature request
about: Suggest an idea for this project.
title: ''
labels: ''
assignees: ''
---

<!--

    Please do *NOT* ask usage questions in Github issues.

    If your issue is not a feature request or bug report use our community support.

    https://prometheus.io/community/

-->
## Proposal
**Use case. Why is this important?**

*“Nice to have” is not a good use case. :)*
